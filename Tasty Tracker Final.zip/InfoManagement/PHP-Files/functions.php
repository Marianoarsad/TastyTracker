<?php
function check_login($conn){
    if(isset($_SESSION['user_id'])){

        $user_id = $_SESSION['user_id'];
        $query = "SELECT * FROM users WHERE user_id = '$user_id' limit 1";

        $result = mysqli_query($conn, $query);

        if($result){

            $user_data = mysqli_fetch_assoc($result);
            return $user_data;
        }
    } else if (!isset($_SESSION['user_id'])) {
        header("Location: Login.php");
        die;
    }
}
?>