<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "infomanagement";

if (!$conn = mysqli_connect($servername, $username, $password, $database)) {
    die("Connection failed: ". mysqli_connect_error()); 
}

?>